from textsummerizer . logging import logger

logger.info("welcome to our custom logging")